Sprint 1 Code
=============

You may use this simple main menu with your ELSA model to produce a complete executable, OR you may write your own if you prefer.

Details of the ELSA model, including class diagram and implementation guidelines, are on Canvas.
